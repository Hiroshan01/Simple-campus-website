<?php
$servername = "localhost"; //  database server's address
$username = "root";        // database username
$password = "";            //  database password is empty)
$dbname = "university";    // the name of your database

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection IF ERRor there?
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
?>
