<?php
session_start();
if ($_SESSION['user_type'] !== 'admin') {
    header("Location: login.html");
    exit();
}
require 'db.php'; 

// Handle search request SQL -->
if (isset($_POST['search_nic'])) {
    $nic = $_POST['search_nic'];
    $query = "SELECT * FROM students WHERE nic = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("s", $nic);
    $stmt->execute();
    $result = $stmt->get_result();
    $student = $result->fetch_assoc();
}

// Handle update request sQL-->
if (isset($_POST['update'])) {
    $nic = $_POST['nic'];
    $full_name = $_POST['full_name'];
    $address = $_POST['address'];
    $phone_number = $_POST['phone_number'];
    $course = $_POST['course'];

    $query = "UPDATE students SET full_name = ?, address = ?, phone_number = ?, course = ? WHERE nic = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("sssss", $full_name, $address, $phone_number, $course, $nic);
    $stmt->execute();

    echo "Student details updated successfully.";
}

// Handle delete request SQL -->
if (isset($_POST['delete'])) {
    $nic = $_POST['nic'];

    $query = "DELETE FROM students WHERE nic = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("s", $nic);
    $stmt->execute();

    echo "Student record deleted successfully.";
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-image: url('uni3.png'); 
            background-size: cover; 
            background-position: center; 
            background-attachment: fixed; 
            margin: 0;
            padding: 0;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
        }
        .dashboard-container {
            background-color: #ffffff;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            max-width: 600px;
            width: 100%;
        }
        h1 {
            margin-bottom: 20px;
        }
        form {
            margin-bottom: 20px;
        }
        input, textarea, button {
            padding: 10px;
            margin: 10px 0;
            width: 100%;
            border: 1px solid #ccc;
            border-radius: 5px;
        }
        button {
            background-color: #007bff;
            color: white;
            border: none;
            cursor: pointer;
        }
        button:hover {
            background-color: #0056b3;
        }
        .delete-button {
            background-color: #dc3545;
        }
        .delete-button:hover {
            background-color: #c82333;
        }
    </style>
</head>
<body>
    <div class="dashboard-container">
        <h1>Admin Dashboard</h1>
        <form method="post" action="">
            <h2>Search Student</h2>
            <input type="text" name="search_nic" placeholder="Enter NIC" required>
            <button type="submit">Search</button>
        </form>

        <?php if (isset($student)): ?>
            <h2>Student Details</h2>
            <form method="post" action="">
                <input type="hidden" name="nic" value="<?php echo htmlspecialchars($student['nic']); ?>">
                <input type="text" name="full_name" value="<?php echo htmlspecialchars($student['full_name']); ?>" required>
                <textarea name="address" required><?php echo htmlspecialchars($student['address']); ?></textarea>
                <input type="text" name="phone_number" value="<?php echo htmlspecialchars($student['phone_number']); ?>" required>
                <input type="text" name="course" value="<?php echo htmlspecialchars($student['course']); ?>" required>
                <button type="submit" name="update">Update</button>
                <button type="submit" name="delete" class="delete-button">Delete</button>
            </form>
        <?php endif; ?>
    </div>
</body>
</html>
