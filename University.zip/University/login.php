<?php
session_start();
require 'db.php'; // Include your database connection file

$username = $_POST['username'];
$password = md5($_POST['password']); 

// Check if admin, who has database.
$query = "SELECT * FROM admins WHERE username = ? AND password = ?";
$stmt = $conn->prepare($query);
$stmt->bind_param("ss", $username, $password);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows > 0) {
    $_SESSION['user_type'] = 'admin';
    header("Location: admin_dashboard.php"); // Redirect to admin dashboard part
    exit();
}

// Check if student regtration DB
$query = "SELECT * FROM students WHERE username = ? AND password = ?";
$stmt = $conn->prepare($query);
$stmt->bind_param("ss", $username, $password);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows > 0) {
    $_SESSION['user_type'] = 'student';
    $_SESSION['username'] = $username;
    header("Location: student_dashboard.php"); // Redirect to student dashboard
    exit();
}

echo "Invalid username or password.";
?>
