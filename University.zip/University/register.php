<?php
session_start();
require 'db.php'; 
$username = $_POST['username'];
$password = md5($_POST['password']); 
$nic = $_POST['nic'];
$full_name = $_POST['full_name'];
$address = $_POST['address'];
$phone_number = $_POST['phone_number'];
$course = $_POST['course'];

// Check if username already exists show student detailas
$query = "SELECT * FROM students WHERE username = ?";
$stmt = $conn->prepare($query);
$stmt->bind_param("s", $username);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows > 0) {
    echo "Username already exists.";
    exit();
}

// Insert new student record update
$query = "INSERT INTO students (username, password, nic, full_name, address, phone_number, course) VALUES (?, ?, ?, ?, ?, ?, ?)";
$stmt = $conn->prepare($query);
$stmt->bind_param("sssssss", $username, $password, $nic, $full_name, $address, $phone_number, $course);
$stmt->execute();

if ($stmt->affected_rows > 0) {
    echo "Registration successful. <a href='login.html'>Login here</a>";
} else {
    echo "Registration failed.";
}
?>
